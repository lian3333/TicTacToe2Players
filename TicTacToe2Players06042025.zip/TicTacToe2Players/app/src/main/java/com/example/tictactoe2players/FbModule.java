package com.example.tictactoe2players;

import android.content.Context;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FbModule {
    private Context context;
    private FirebaseDatabase database;
    private DatabaseReference reference;

    public FbModule(Context context) {
        this.context = context;
        database=FirebaseDatabase.getInstance();
        reference=database.getReference("play");

        initFirebaseListener();
    }

    private void initFirebaseListener() {

    }
     public void setPositionToFirebase(Position position){
        reference.setValue(position);
     }
}
